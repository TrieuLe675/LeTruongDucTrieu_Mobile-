package com.example.customlistview;

public class Phone {
    int img_Phone;
    String txt_Phone;

    public int getImg_Phone() {
        return img_Phone;
    }

    public void setImg_Phone(int img_Phone) {
        this.img_Phone = img_Phone;
    }

    public String getTxt_Phone() {
        return txt_Phone;
    }

    public void setTxt_Phone(String txt_Phone) {
        this.txt_Phone = txt_Phone;
    }

    public Phone(int img_Phone, String txt_Phone) {
        this.img_Phone = img_Phone;
        this.txt_Phone = txt_Phone;
    }
}
