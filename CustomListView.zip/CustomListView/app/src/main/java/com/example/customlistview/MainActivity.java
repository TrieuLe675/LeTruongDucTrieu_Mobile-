package com.example.customlistview;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //Khai báo các biến
    int image[] = {R.drawable.ic_launcher_background}; //chọn 1 hình khác đã đươc add vào drawable
    String name[] = {"Iphone 14"};
    //khai báo listView
    myArrayAdapter myAdapter;
    ArrayList<Phone> mylist;
    ListView lvPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //B1: Khởi tạo dữ liệu cho lvPhone, mylist
        lvPhone = findViewById(R.id.lvPhone);
        mylist = new ArrayList<>();
        for (int i = 0; i < name.length; i++) {
            mylist.add(new Phone(image[i], name[i]));
        }
        myAdapter = new myArrayAdapter(this, R.layout.layout_item, mylist);
        lvPhone.setAdapter(myAdapter);
    }
}