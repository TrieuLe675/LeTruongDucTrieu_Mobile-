package com.example.customlistview;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class myArrayAdapter extends ArrayAdapter<Phone> {
    Activity context;
    int idLayout;
    ArrayList<Phone> mylist;

    // Constructor
    public myArrayAdapter(Activity context, int idLayout, ArrayList<Phone> mylist) {
        super(context, idLayout, mylist);
        this.context = context;
        this.idLayout = idLayout;
        this.mylist = mylist;
    }
    //goi phuong thuc getView de sap xep du lieu hien thi len View


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //Tạo đế để chứa layout

        LayoutInflater myInflater = context.getLayoutInflater();
        //Đặt idLayout lên đế để tạo thành View
        convertView = myInflater.inflate(idLayout, null);

        //Lấy từng phần tử trong danh sách mylist để hiển thị lên View
        Phone myPhone = mylist.get(position);
        //Khai báo, tham chiếu id và hiển thị ảnh lên ImageView
        ImageView imgPhone = convertView.findViewById(R.id.imgPhone);
        imgPhone.setImageResource(myPhone.getImg_Phone());

        //Khai báo, tham chiếu id và hiển thị tên điện thoại lên TextView
        TextView txtPhone = convertView.findViewById(R.id.txtPhone);
        txtPhone.setText(myPhone.getTxt_Phone());
        return convertView;
    }
}