package com.example.simplelistview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.MessageFormat;

public class MainActivity extends AppCompatActivity {
//khai báo biến
    TextView txtSelection;
    ListView lvPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //1.Khởi tạo dữ liệu cho data source
        String arr[] = {"Iphone 7","Iphone 8","Iphone X","Iphone 11","Iphone 15"};

        //2.Khai báo adapter và gán dữ liệu Data source vào Adapter
        ArrayAdapter<String> myadapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1, arr);

        //3.Khai báo listview và đưa Adapter vào list view
        txtSelection = findViewById(R.id.txtSelection);
        lvPhone = findViewById(R.id.lvPhone);
        lvPhone.setAdapter(myadapter);

        //4.Viết sự kiện khi click vào 1 dòng trên listview
        lvPhone.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                txtSelection.setText(MessageFormat.format("Vị trí{0}:{1}", position, arr[position]));
            }
        });
            }

        }


