package com.example.bai7intentexplicit;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class child_activity extends AppCompatActivity {
    //khai báo biến
    Button btnChild;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.child_activity);

        //Ánh xạ
        btnChild = findViewById(R.id.btnChild);
        btnChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent childIntent = new Intent(child_activity.this, MainActivity.class);
                startActivity(childIntent);
            }
        });

    }
}